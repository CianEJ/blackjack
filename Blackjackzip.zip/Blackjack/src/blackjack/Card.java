package blackjack;

class Card {
//creates the playing card
	
private int rank;
//the rank of the card

private int suit;
//the suit of the card

private int value;
//the value of a card

private static String[] ranks = {"Ace","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Jack","Queen","King"};
private static String[] suits = {"Clubs","Spades","Hearts","Diamonds"};

Card(int suit, int values)
//this integer identifies the value and suit of a particular card
{
    this.rank=values;
    this.suit=suit;
}

public String toString()
{
    return ranks[rank]+" of "+suits[suit];
}

public int getRank()
{
    return rank;
}

public int getSuit()
{
    return suit;
}

public int getValue()
{
    if(rank>10)
    {
        value=10;
    }
    else if(rank==1)
    {
        value=11;
    }
    else
    {
        value=rank;
    }
    return value;
}

public void setValue(int set)
{
    value = set;
}
}
