package blackjack;

import java.util.ArrayList;
import java.util.Arrays;

class Dealer {
	//creates a dealer
	
ArrayList<Card> hand;
//creates the dealer's hand

private int handvalue=0;
private Card[] aHand;
//converts the dealer's hand to an array

private int AceCounter;
//checks for an ace

Dealer(Deck deck)
{
    hand = new ArrayList<>();
    aHand = new Card[]{};
    int AceCounter=0;
    for(int i=0; i<2; i++)
    {
        hand.add(deck.drawCard());
    }
    aHand = hand.toArray(aHand);
    for(int i=0; i<aHand.length; i++)
    {
        handvalue += aHand[i].getValue();
        if(aHand[i].getValue()==11)
        {
            AceCounter++;
        }
        while(AceCounter>0 && handvalue>21)
        {
            handvalue-=10;
            AceCounter--;
        }
    }
}

public void showFirstCard()
{
    Card[] firstCard = new Card[]{};
    firstCard = hand.toArray(firstCard);
    System.out.println("["+firstCard[0]+"]");
}

public void Hit(Deck deck)
{
    hand.add(deck.drawCard());
    aHand = hand.toArray(aHand);
    handvalue = 0;
    for(int i=0; i<aHand.length; i++)
    {
        handvalue += aHand[i].getValue();
        if(aHand[i].getValue()==11)
        {
            AceCounter++;
        }
        while(AceCounter>0 && handvalue>21)
        {
            handvalue-=10;
            AceCounter--;
        }
    }
}

public int takeTurn(Deck deck)
//the dealer's turn is taken

{
  while(wantsToHit())
  {
      System.out.println("The dealer hits");
      Hit(deck);
      if(busted(handvalue))
      {
          break;
      }
  }
  if(handvalue<=21)
  {
      System.out.print("The dealer stands.");
  }
  return handvalue;
}

public boolean wantsToHit()
//does the dealer want to hit
{
    if(handvalue<17)
    {
        return true;
    }
    return false;
}

public void showHand()
//shows the hand of the dealer
{
    System.out.println(hand);
}

public int getHandValue()
//calculates the value of the dealers hand
{
    return handvalue; }
    
    public boolean hasBlackJack()
    {
        if(hand.size()==2 && handvalue==21)
        {
            System.out.println("The dealer has blackjack!");
            return true;
        }
        return false;
}

public boolean busted(int handvalue)
//check to see if the dealer has busted
{
    if(handvalue>21)
    {
        System.out.println("The dealer is bust!");
        return true;
    }
    return false;
}
}


