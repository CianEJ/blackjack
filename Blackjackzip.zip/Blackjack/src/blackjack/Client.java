package blackjack;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client 
{	
	String					ipaddress;
	int						portnumber;
	//variables used to store IP Address
	
	DataInputStream 		dis;
	DataOutputStream 		dos;
	
	public Client(String ipaddress, int port) {
		this.ipaddress = ipaddress;
		this.portnumber = port;
		
		Scanner scn = new Scanner(System.in); 
 
		try {
			Socket s = new Socket(this.ipaddress, this.portnumber);
			
			dis = new DataInputStream(s.getInputStream()); 
			dos = new DataOutputStream(s.getOutputStream()); 
			
			while (true) 
			{ 
				System.out.println(dis.readUTF()); 
				String tosend = scn.nextLine(); 
				dos.writeUTF(tosend); 
				
				if(tosend.equals("Close")) 
				{ 
					System.out.println("Connection closing : " + s); 
					s.close(); 
					System.out.println("Connection now closed"); 
					break; 
				} 
				String received = dis.readUTF(); 
				System.out.println(received); 
			}
			scn.close(); 
			dis.close(); 
			dos.close(); 
			
		} catch (UnknownHostException e) {
		
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}	
	}
	
	public static void main(String[] args) throws IOException 
	{ 
		
		String ip = "127.0.0.1";
		int port = 5056;
		
	} 
} 

