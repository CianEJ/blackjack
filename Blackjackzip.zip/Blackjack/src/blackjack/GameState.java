package blackjack;

import java.util.HashMap;
import java.util.List;

public class GameState {
    public enum Suit { HEARTS, DIAMONDS, CLUBS, SPADES }
    public enum Rank { Ace,Two,Three,Four,Five,Six,Seven,Eight,Nine,Ten,Jack,Queen,King}
    public static class Card {
       Suit suit;
       Rank rank;
    }
    public static class Deck {
       List<Card> cards; 
       // Cards remaining in the deck
    }
    public static class Player {
       // Cards on the table for a player
       List<Card> cards;
       Integer id;
       Double money;
    }
    HashMap<Integer, Player> players;
    Integer activePlayerId;
}

